/*
 * Basics of Computer Graphics Exercise
 */
 
#include "assignment.hh"

namespace task
{

bool convex(const glm::vec2& prev, const glm::vec2& curr, const glm::vec2& next)
{
    // True iff the vertex curr is a convex corner.
    // Assume counter-clockwise vertex order.

    glm::vec2 u = curr - prev;
    glm::vec2 v = next - curr;

    float decision = u.x * v.y - v.x * u.y;

    return decision > 0;
}

bool inTriangle(const glm::vec2& p, const glm::vec2& a, const glm::vec2& b, const glm::vec2& c)
{
    // True iff the point p lies within the triangle a, b, c.
    // Assume counter-clockwise vertex order.

    glm::vec2 AB = b - a;
    glm::vec2 BC = c - b;
    glm::vec2 CA = a - c;

    float d = 0;
    
    glm::vec2 v;

    v = p - b;
    d = AB.x * v.y - AB.y * v.x;
    if (d < 0) return false;

    v = p - c;
    d = BC.x * v.y - BC.y * v.x;
    if (d < 0) return false;

    v = p - a;
    d = CA.x * v.y - CA.y * v.x;
    if (d < 0) return false;

    return true;
}

bool triangleEmpty(const int i_a, const int i_b, const int i_c, const std::vector<glm::vec2>& vertices)
{
    // True iff there is no other vertex inside the triangle a, b, c.
    
    for (int i = 0; i < vertices.size(); i++) {
        if (i == i_a || i == i_b || i == i_c) continue;

        if(inTriangle(vertices.at(i), vertices.at(i_a), vertices.at(i_b), vertices.at(i_c))) return false;
    }

    return true;
}

void triangulate(const std::vector<glm::vec2>& vertices, std::vector<int>& triangles)
{
    // Loop through vertices and clip away ears until only two vertices are left.
    // Input:  "vertices" contains the polygon vertices in counter-clockwise order.
    // Output: "triangles" contains indices into the "vertices" vector. Each triplet
    //         of consecutive indices specifies a triangle in counter-clockwise order.

    size_t n = vertices.size();
    if (vertices.size() < 3)
        return;

    std::cout << "Starting triangulation of a " << n << "-gon." << std::endl;

    // True iff the vertex has been clipped.
    std::vector<bool> clipped(n, false);

    int cur = 0;
    int prev = n - 1;
    int next = 1;

    while (triangles.size()/3 < n-2) {
        if (convex(vertices.at(prev), vertices.at(cur), vertices.at(next))) {
            if (triangleEmpty(prev, cur, next, vertices)) {
                triangles.push_back(prev); triangles.push_back(cur); triangles.push_back(next);
                clipped.at(cur) = true;

                cur = next;

                do {
                    next++;
                    next = next % n;
                } while (clipped.at(next));

                continue;
            }
        }

        prev = cur;
        cur = next;

        do {
            next++;
            next = next % n;
        } while (clipped.at(next));
    }
}

void initCustomResources()
{
}

void deleteCustomResources()
{
}

}
